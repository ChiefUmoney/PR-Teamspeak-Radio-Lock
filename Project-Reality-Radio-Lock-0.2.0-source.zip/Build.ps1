param([switch]$SkipTests)
$ErrorActionPreference = 'Stop'
$radioRoot = $PSScriptRoot
$radioWork = Join-Path $radioRoot 'build'
New-Item -ItemType Directory -Force $radioWork | Out-Null
$radioVswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$radioVs = & $radioVswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (!$radioVs) { throw 'Visual Studio C++ Build Tools and Windows SDK are required.' }
$radioCommands = @(
    '@echo off',
    ('call "' + $radioVs + '\VC\Auxiliary\Build\vcvars64.bat" >nul'),
    'if errorlevel 1 exit /b 1',
    ('cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /I "' + $radioRoot + '\source\sdk" "' + $radioRoot + '\source\plugin.cpp" /Fo"' + $radioWork + '\plugin.obj" /link /OUT:"' + $radioWork + '\pr_radio_lock_win64.dll" /IMPLIB:"' + $radioWork + '\pr_radio_lock.lib"'),
    'if errorlevel 1 exit /b 1',
    ('cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT "' + $radioRoot + '\source\tests.cpp" /Fo"' + $radioWork + '\tests.obj" /Fe"' + $radioWork + '\radio-tests.exe"'),
    'if errorlevel 1 exit /b 1',
    ('cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /I "' + $radioRoot + '\source\sdk" "' + $radioRoot + '\source\dll_smoke_test.cpp" /Fo"' + $radioWork + '\smoke.obj" /Fe"' + $radioWork + '\dll-smoke.exe"'),
    'if errorlevel 1 exit /b 1'
)
$radioCommandFile = Join-Path $radioWork 'compile.cmd'
[IO.File]::WriteAllText($radioCommandFile, ($radioCommands -join "`r`n") + "`r`n")
& $env:ComSpec /d /c $radioCommandFile
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
if (!$SkipTests) {
    & "$radioWork\radio-tests.exe"
    if ($LASTEXITCODE -ne 0) { throw 'Core radio tests failed.' }
    & "$radioWork\dll-smoke.exe" "$radioWork\pr_radio_lock_win64.dll"
    if ($LASTEXITCODE -ne 0) { throw 'DLL smoke test failed.' }
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$radioPackage = Join-Path $radioRoot 'Project-Reality-Radio-Lock-0.2.0-win64.ts3_plugin'
if (Test-Path -LiteralPath $radioPackage) { Remove-Item -LiteralPath $radioPackage }
$radioZip = [IO.Compression.ZipFile]::Open($radioPackage,[IO.Compression.ZipArchiveMode]::Create)
try {
    $radioEntries = @{
        'package.ini' = "$radioRoot\package.ini"
        'plugins/pr_radio_lock_win64.dll' = "$radioWork\pr_radio_lock_win64.dll"
        'plugins/pr_radio_lock/busy.wav' = "$radioRoot\sounds\busy.wav"
        'plugins/pr_radio_lock/permit.wav' = "$radioRoot\sounds\permit.wav"
        'plugins/pr_radio_lock/README.md' = "$radioRoot\README.md"
    }
    foreach ($radioEntry in $radioEntries.GetEnumerator()) {
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($radioZip,$radioEntry.Value,$radioEntry.Key) | Out-Null
    }
} finally { $radioZip.Dispose() }
Write-Output "Created $radioPackage"
