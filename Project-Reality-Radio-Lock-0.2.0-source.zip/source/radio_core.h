#pragma once
#include <algorithm>
#include <cstdint>
#include <map>
#include <sstream>
#include <string>
#include <vector>

namespace radio {
using Time = uint64_t;
using Client = uint16_t;
constexpr Time CLIENT_LEASE = 1600;
constexpr Time SERVER_LEASE = 2600;
constexpr Time RENEW = 650;
constexpr Time SETTLE = 3000;
constexpr Time TURNAROUND = 350;

struct Message {
    char kind = 0; // R request/renew, G grant, D denied, L release
    uint64_t channel = 0, epoch = 0, attempt = 0, sequence = 0;
};
inline std::string encode(const Message& m) {
    return "PRRL1 " + std::string(1, m.kind) + " " + std::to_string(m.channel) + " " +
        std::to_string(m.epoch) + " " + std::to_string(m.attempt) + " " + std::to_string(m.sequence);
}
inline bool decode(const std::string& text, Message& m) {
    if (text.size() > 160) return false;
    std::istringstream in(text);
    std::string magic, kind, extra;
    if (!(in >> magic >> kind) || magic != "PRRL1" || kind.size() != 1 ||
        std::string("RGDL").find(kind[0]) == std::string::npos) return false;
    uint64_t* values[] = {&m.channel, &m.epoch, &m.attempt, &m.sequence};
    for (auto value : values) {
        std::string token;
        if (!(in >> token) || token.empty() || token.size() > 20) return false;
        uint64_t result = 0;
        for (char c : token) {
            if (c < '0' || c > '9' || result > (UINT64_MAX - (c - '0')) / 10) return false;
            result = result * 10 + (c - '0');
        }
        *value = result;
    }
    m.kind = kind[0];
    return !(in >> extra) && m.channel && m.epoch && m.attempt && m.sequence;
}
struct Send { Client target; Message message; };
struct Node {
    Client me = 0, leader = 0, owner = 0;
    uint64_t channel = 0, epoch = 0, attempt = 1, sequence = 0, ownerAttempt = 0;
    Time readyAt = 0, ownerUntil = 0, blockedUntil = 0, grantUntil = 0;
    Time lastRequest = 0, startedAt = 0;
    bool held = false, locked = true, busyTone = false, permitTone = false;
    bool everGranted = false;
    std::vector<Client> members;
    std::map<uint64_t, Time> pending;
    std::vector<Send> out;

    void configure(Client self, uint64_t chan, uint64_t generation,
                   std::vector<Client> people, Time now) {
        std::sort(people.begin(), people.end());
        if (me == self && channel == chan && epoch == generation && members == people) return;
        me = self; channel = chan; epoch = generation; members = std::move(people);
        leader = members.empty() ? 0 : members.front();
        owner = 0; ownerAttempt = 0; ownerUntil = 0; blockedUntil = 0;
        grantUntil = 0; pending.clear(); out.clear();
        held = false; locked = true; everGranted = false;
        busyTone = permitTone = false;
        readyAt = now + SETTLE;
        ++attempt;
    }
    void emit(Client to, char kind, uint64_t a, uint64_t seq) {
        out.push_back({to, {kind, channel, epoch, a, seq}});
    }
    void stop(bool tone) {
        grantUntil = 0;
        if (held && sequence) emit(leader, 'L', attempt, sequence);
        pending.clear(); locked = true;
        busyTone = busyTone || tone;
    }
    bool mayTransmit(Time now) const {
        // A healthy grant can renew for as long as PTT remains held. Leases only
        // detect lost communication; they are not a maximum transmission length.
        return held && !locked && everGranted && now < grantUntil;
    }
    void tick(Time now, bool ptt) {
        if (owner && now >= ownerUntil) { owner = 0; blockedUntil = now + TURNAROUND; }
        if (!ptt) {
            if (held) stop(false);
            held = false; locked = false; everGranted = false;
            return;
        }
        if (!held) {
            held = true; ++attempt; sequence = 0; pending.clear();
            startedAt = now; lastRequest = 0; everGranted = false;
            if (locked || !leader || now < readyAt) { locked = true; busyTone = true; return; }
        }
        if (locked) return;
        if ((everGranted && now >= grantUntil) ||
            (!everGranted && now - startedAt >= CLIENT_LEASE)) {
            stop(true); return;
        }
        if (!sequence || now - lastRequest >= RENEW) {
            lastRequest = now;
            pending[++sequence] = now;
            emit(leader, 'R', attempt, sequence);
            while (pending.size() > 5) pending.erase(pending.begin());
        }
    }
    void receive(Client from, const Message& m, Time now) {
        if (m.channel != channel || m.epoch != epoch ||
            !std::binary_search(members.begin(), members.end(), from)) return;
        if ((m.kind == 'R' || m.kind == 'L') && me == leader) {
            if (m.kind == 'L') {
                if (owner == from && ownerAttempt == m.attempt) {
                    owner = 0; ownerUntil = 0; blockedUntil = now + TURNAROUND;
                }
                return;
            }
            if (owner && now >= ownerUntil) { owner = 0; blockedUntil = now + TURNAROUND; }
            if (now < readyAt || now < blockedUntil ||
                (owner && (owner != from || ownerAttempt != m.attempt))) {
                emit(from, 'D', m.attempt, m.sequence); return;
            }
            owner = from; ownerAttempt = m.attempt; ownerUntil = now + SERVER_LEASE;
            emit(from, 'G', m.attempt, m.sequence);
            return;
        }
        if (from != leader || m.attempt != attempt || !held || locked) return;
        auto found = pending.find(m.sequence);
        if (found == pending.end()) return;
        Time until = found->second + CLIENT_LEASE; // Based on send time, never receive time.
        pending.erase(found);
        if (m.kind == 'D') { stop(true); return; }
        if (m.kind != 'G' || until <= now) return;
        if (!everGranted) permitTone = true;
        everGranted = true;
        grantUntil = std::max(grantUntil, until);
    }
};
}
