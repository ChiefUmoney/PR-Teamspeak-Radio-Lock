#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#pragma comment(lib, "bcrypt.lib")
#include <atomic>
#include <chrono>
#include <cstring>
#include <deque>
#include <mutex>
#include <set>
#include <thread>
#include "teamspeak/public_definitions.h"
#include "teamspeak/public_rare_definitions.h"
#include "ts3_functions.h"
#include "radio_core.h"

#define EXPORT extern "C" __declspec(dllexport)
static TS3Functions api{};
static std::mutex mutex;
static std::atomic<bool> running{false};
static std::thread worker;
static std::string pluginId, soundPath;
static std::atomic<uint64> attemptSeed{1};
struct State {
    radio::Node node;
    bool known = false, enabled = false, validPtt = false;
    radio::Time checkedAt = 0;
    uint64 revision = 0;
    State() { node.attempt = attemptSeed.fetch_add(1ULL << 32); }
};
struct Incoming { uint64 server; anyID from; radio::Message message; };
static std::map<uint64, State> states;
static std::deque<Incoming> inbox;
static radio::Time nowMs() { return GetTickCount64(); }

struct Snapshot {
    uint64 server = 0, channel = 0, epoch = 1469598103934665603ULL;
    anyID self = 0;
    bool valid = false, enabled = false, pttMode = false, held = false;
    std::vector<anyID> members;
    uint64 revision = 0;
};
static void hashByte(uint64& hash, unsigned char b) { hash ^= b; hash *= 1099511628211ULL; }
static Snapshot inspect(uint64 server) {
    Snapshot s; s.server = server;
    { std::lock_guard<std::mutex> lock(mutex); s.revision = states[server].revision; }
    int status = 0;
    if (api.getConnectionStatus(server, &status) || status != STATUS_CONNECTION_ESTABLISHED ||
        api.getClientID(server, &s.self) || api.getChannelOfClient(server, s.self, &s.channel)) return s;
    char* topic = nullptr;
    if (api.getChannelVariableAsString(server, s.channel, CHANNEL_TOPIC, &topic)) return s;
    s.enabled = topic && strstr(topic, "[PR-RADIO]");
    if (topic) api.freeMemory(topic);
    if (!s.enabled) { s.valid = true; return s; }
    char* vad = nullptr;
    if (!api.getPreProcessorConfigValue(server, "vad", &vad)) {
        s.pttMode = vad && (!strcmp(vad, "false") || !strcmp(vad, "0"));
        if (vad) api.freeMemory(vad);
    }
    int deactivated = 1, muted = 1, hardware = 0;
    if (api.getClientSelfVariableAsInt(server, CLIENT_INPUT_DEACTIVATED, &deactivated) ||
        api.getClientSelfVariableAsInt(server, CLIENT_INPUT_MUTED, &muted) ||
        api.getClientSelfVariableAsInt(server, CLIENT_INPUT_HARDWARE, &hardware)) return s;
    s.held = deactivated == INPUT_ACTIVE && muted == MUTEINPUT_NONE && hardware != 0;
    anyID* clients = nullptr;
    if (api.getChannelClientList(server, s.channel, &clients) || !clients) return s;
    bool ok = true;
    for (anyID* p = clients; *p; ++p) {
        int type = 0;
        if (api.getClientVariableAsInt(server, *p, CLIENT_TYPE, &type)) { ok = false; break; }
        if (!type) s.members.push_back(*p);
    }
    api.freeMemory(clients);
    if (!ok || s.members.empty()) return s;
    std::sort(s.members.begin(), s.members.end());
    for (anyID id : s.members) {
        hashByte(s.epoch, static_cast<unsigned char>(id));
        hashByte(s.epoch, static_cast<unsigned char>(id >> 8));
        char* uid = nullptr;
        if (api.getClientVariableAsString(server, id, CLIENT_UNIQUE_IDENTIFIER, &uid) || !uid) return s;
        for (const unsigned char* p = reinterpret_cast<unsigned char*>(uid); *p; ++p) hashByte(s.epoch, *p);
        hashByte(s.epoch, 0);
        api.freeMemory(uid);
    }
    if (!s.epoch) s.epoch = 1;
    s.valid = true;
    return s;
}
static void invalidate(uint64 server) {
    std::lock_guard<std::mutex> lock(mutex);
    auto& s = states[server];
    s.known = false; s.node.grantUntil = 0; s.node.epoch = 0; ++s.revision;
}
static void moved(uint64 server, anyID client, uint64 oldChannel, uint64 newChannel) {
    std::lock_guard<std::mutex> lock(mutex);
    auto& s = states[server];
    if (!s.known || client == s.node.me || oldChannel == s.node.channel || newChannel == s.node.channel) {
        s.known = false; s.node.grantUntil = 0; s.node.epoch = 0; ++s.revision;
    }
}
static void channelChanged(uint64 server, uint64 channel) {
    std::lock_guard<std::mutex> lock(mutex);
    auto& s = states[server];
    if (!s.known || channel == s.node.channel) {
        s.known = false; s.node.grantUntil = 0; s.node.epoch = 0; ++s.revision;
    }
}
static void run() {
    while (running) {
        uint64* servers = nullptr;
        std::vector<Snapshot> snaps;
        if (!api.getServerConnectionHandlerList(&servers) && servers) {
            for (uint64* p = servers; *p; ++p) snaps.push_back(inspect(*p));
            api.freeMemory(servers);
        }
        struct Out { uint64 server; radio::Send send; };
        std::vector<Out> outgoing;
        std::vector<std::pair<uint64, std::string>> notices;
        std::vector<std::pair<uint64, bool>> tones;
        std::string id, path;
        const auto now = nowMs();
        {
            std::lock_guard<std::mutex> lock(mutex);
            id = pluginId; path = soundPath;
            std::set<uint64> present;
            for (auto& snap : snaps) {
                present.insert(snap.server);
                auto& s = states[snap.server];
                if (s.revision != snap.revision) continue; // Membership changed during the API reads.
                bool changed = !s.known || s.enabled != snap.enabled || s.node.channel != snap.channel;
                if (!snap.valid) { s.known = false; s.node.grantUntil = 0; s.node.epoch = 0; continue; }
                s.known = true; s.enabled = snap.enabled; s.validPtt = snap.pttMode; s.checkedAt = now;
                if (!snap.enabled) {
                    const auto previousAttempt = s.node.attempt;
                    s.node = {}; s.node.attempt = previousAttempt + 1;
                    s.node.channel = snap.channel; s.node.me = snap.self; continue;
                }
                s.node.configure(snap.self, snap.channel, snap.epoch, snap.members, now);
                if (changed) notices.push_back({snap.server,
                    "[PR Radio Lock] Protected channel. Keep normal Push-To-Talk enabled. Wait 3 seconds, release PTT, then hold it and wait for the permit beep. Every channel member needs this plugin."});
                s.node.tick(now, snap.pttMode && snap.held);
            }
            for (auto it = states.begin(); it != states.end();) {
                if (!present.count(it->first)) it = states.erase(it); else ++it;
            }
            for (auto& event : inbox) {
                auto it = states.find(event.server);
                if (it != states.end() && it->second.known && it->second.enabled)
                    it->second.node.receive(event.from, event.message, now);
            }
            inbox.clear();
            for (auto& pair : states) {
                auto& s = pair.second;
                if (!s.known || !s.enabled) continue;
                // Self requests are handled locally; other commands go through TeamSpeak.
                for (size_t i = 0; i < s.node.out.size() && i < 32; ++i) {
                    auto send = s.node.out[i];
                    if (send.target == s.node.me) s.node.receive(s.node.me, send.message, now);
                    else outgoing.push_back({pair.first, send});
                }
                s.node.out.clear();
                if (s.node.busyTone) {
                    tones.push_back({pair.first, false});
                    notices.push_back({pair.first, "[PR Radio Lock] Busy or controller unavailable. Release PTT, then try again when the channel is clear."});
                } else if (s.node.permitTone) tones.push_back({pair.first, true});
                s.node.busyTone = s.node.permitTone = false;
            }
        }
        if (!id.empty()) for (const auto& item : outgoing) {
            anyID targets[] = {item.send.target, 0};
            const auto command = radio::encode(item.send.message);
            api.sendPluginCommand(item.server, id.c_str(), command.c_str(), PluginCommandTarget_CLIENT, targets, nullptr);
        }
        for (auto& notice : notices) api.printMessage(notice.first, notice.second.c_str(), PLUGIN_MESSAGE_TARGET_SERVER);
        if (!path.empty()) for (auto tone : tones)
            api.playWaveFile(tone.first, (path + (tone.second ? "permit.wav" : "busy.wav")).c_str());
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
}
EXPORT const char* ts3plugin_name() { return "Project Reality Radio Lock"; }
EXPORT const char* ts3plugin_version() { return "0.2.0"; }
EXPORT int ts3plugin_apiVersion() { return 26; }
EXPORT const char* ts3plugin_author() { return "Project Reality"; }
EXPORT const char* ts3plugin_description() {
    return "One-at-a-time channel PTT with no transmission duration limit and a local busy sound. Put [PR-RADIO] in the channel topic. All members need v0.2.0. Keep native PTT. API 26 / Windows x64.";
}
EXPORT void ts3plugin_setFunctionPointers(const TS3Functions funcs) { api = funcs; }
EXPORT int ts3plugin_init() {
    uint64 seed = 0;
    if (BCryptGenRandom(nullptr, reinterpret_cast<PUCHAR>(&seed), sizeof(seed), BCRYPT_USE_SYSTEM_PREFERRED_RNG) < 0) return 1;
    attemptSeed = seed ? seed : 1;
    running = true;
    try { worker = std::thread(run); } catch (...) { running = false; return 1; }
    return 0;
}
EXPORT void ts3plugin_shutdown() {
    running = false;
    if (worker.joinable()) worker.join();
    std::lock_guard<std::mutex> lock(mutex);
    states.clear(); inbox.clear(); pluginId.clear(); soundPath.clear();
}
EXPORT void ts3plugin_registerPluginID(const char* id) {
    char path[2048]{};
    api.getPluginPath(path, sizeof(path), id);
    std::string base(path);
    if (!base.empty() && base.back() != '/' && base.back() != '\\') base += '/';
    std::lock_guard<std::mutex> lock(mutex);
    pluginId = id ? id : ""; soundPath = base + "pr_radio_lock/";
}
EXPORT int ts3plugin_requestAutoload() { return 0; }
EXPORT const char* ts3plugin_commandKeyword() { return "prradio"; }
EXPORT int ts3plugin_processCommand(uint64 server, const char* command) {
    if (!command || (strcmp(command, "status") && strcmp(command, "help"))) return 1;
    std::string text;
    {
        std::lock_guard<std::mutex> lock(mutex);
        auto it = states.find(server);
        if (it == states.end() || !it->second.known) text = "Waiting for channel information; microphone gate is closed.";
        else if (!it->second.enabled) text = "Normal channel. Add [PR-RADIO] to the channel Topic to protect it.";
        else {
            auto& s = it->second;
            text = "Protected channel. Controller client ID: " + std::to_string(s.node.leader) +
                ". Your client ID: " + std::to_string(s.node.me) + ". " +
                (s.validPtt ? "Capture mode ready. " : "Disable Voice Activity Detection and select Push-To-Talk. ") +
                (s.node.mayTransmit(nowMs()) ? "TRANSMITTING." : "Listening / waiting for a radio grant.");
        }
    }
    api.printMessage(server, ("[PR Radio Lock] " + text).c_str(), PLUGIN_MESSAGE_TARGET_SERVER);
    return 0;
}
EXPORT void ts3plugin_onPluginCommandEvent(uint64 server, const char* name, const char* command,
                                          anyID from, const char*, const char*) {
    if (!name || !command || (_stricmp(name, "pr_radio_lock") && _stricmp(name, "pr_radio_lock_win64"))) return;
    // Bound input before allocating or parsing data supplied by another client.
    if (strnlen_s(command, 161) > 160) return;
    radio::Message message;
    if (!radio::decode(command, message)) return;
    std::lock_guard<std::mutex> lock(mutex);
    if (inbox.size() < 1024) inbox.push_back({server, from, message});
}
EXPORT void ts3plugin_onEditCapturedVoiceDataEvent(uint64 server, short* samples,
                                                  int sampleCount, int channels, int* edited) {
    if (!edited) return;
    bool allow = false;
    {
        std::lock_guard<std::mutex> lock(mutex);
        auto it = states.find(server);
        if (it != states.end() && it->second.known) {
            const auto& s = it->second;
            allow = !s.enabled || (s.validPtt && nowMs() - s.checkedAt < 250 && s.node.mayTransmit(nowMs()));
        }
    }
    if (!allow) {
        *edited &= ~2;
        if (samples && sampleCount > 0 && sampleCount <= 48000 && channels > 0 && channels <= 16) {
            memset(samples, 0, size_t(sampleCount) * size_t(channels) * sizeof(short));
            *edited |= 1;
        }
    }
}
EXPORT void ts3plugin_onConnectStatusChangeEvent(uint64 s, int, unsigned int) { invalidate(s); }
EXPORT void ts3plugin_onClientMoveEvent(uint64 s, anyID c, uint64 o, uint64 n, int, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientMoveSubscriptionEvent(uint64 s, anyID c, uint64 o, uint64 n, int) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientMoveTimeoutEvent(uint64 s, anyID c, uint64 o, uint64 n, int, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientMoveMovedEvent(uint64 s, anyID c, uint64 o, uint64 n, int, anyID, const char*, const char*, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientKickFromChannelEvent(uint64 s, anyID c, uint64 o, uint64 n, int, anyID, const char*, const char*, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientKickFromServerEvent(uint64 s, anyID c, uint64 o, uint64 n, int, anyID, const char*, const char*, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onClientBanFromServerEvent(uint64 s, anyID c, uint64 o, uint64 n, int, anyID, const char*, const char*, uint64, const char*) { moved(s,c,o,n); }
EXPORT void ts3plugin_onUpdateChannelEvent(uint64 s, uint64 c) { channelChanged(s,c); }
EXPORT void ts3plugin_onUpdateChannelEditedEvent(uint64 s, uint64 c, anyID, const char*, const char*) { channelChanged(s,c); }
