#include "radio_core.h"
#include <cassert>
#include <iostream>
#include <random>
#include <deque>
using namespace radio;
static void deliver(std::map<Client, Node>& nodes, Time now) {
    for (int round = 0; round < 10; ++round) {
        std::vector<std::pair<Client, Send>> queue;
        for (auto& p : nodes) { for (auto s : p.second.out) queue.push_back({p.first, s}); p.second.out.clear(); }
        if (queue.empty()) return;
        for (auto& p : queue) if (nodes.count(p.second.target))
            nodes.at(p.second.target).receive(p.first, p.second.message, now);
    }
    assert(false);
}
static std::map<Client, Node> ready() {
    std::map<Client, Node> n;
    for (Client i = 1; i <= 3; ++i) { n[i].configure(i, 7, 42, {1,2,3}, 0); n[i].tick(1, false); }
    return n;
}
int main() {
    {
        Message m;
        assert(decode("PRRL1 R 7 42 5 1", m));
        for (auto bad : {"PRRL1 R -1 42 5 1", "PRRL1 R 7 42 5 1 junk", "PRRL1 X 7 42 5 1",
                        "PRRL1 R 0 42 5 1", "PRRL1 R 7 42 5 18446744073709551616", "PRRL1 R 7 42 5 0"})
            assert(!decode(bad, m));
    }
    auto n = ready();
    n[2].tick(3100, true); n[3].tick(3100, true); deliver(n, 3100);
    assert(n[2].mayTransmit(3101)); assert(!n[3].mayTransmit(3101)); assert(n[3].locked);
    assert(!n[1].busyTone && !n[2].busyTone && n[3].busyTone);
    n[3].busyTone = false;
    n[2].tick(3150, false); deliver(n, 3150);
    n[3].tick(3600, true); deliver(n, 3600);
    assert(!n[3].mayTransmit(3600)); // A denied key press must not auto-transmit later.
    assert(!n[3].busyTone); // No repeating alert while a denied key remains held.
    n[3].tick(3601, false); n[3].tick(3602, true); deliver(n, 3602);
    assert(n[3].mayTransmit(3603));
    assert(!n[3].mayTransmit(5300)); // Lost renewals expire at capture time.
    {
        auto x = ready(); x[2].tick(3100, true);
        Message request = x[2].out.front().message; x[2].out.clear();
        auto grant = request; grant.kind = 'G';
        x[2].receive(3, grant, 3110); assert(!x[2].mayTransmit(3110)); // Wrong coordinator.
        grant.epoch++; x[2].receive(1, grant, 3110); assert(!x[2].mayTransmit(3110));
        grant.epoch--; x[2].receive(1, grant, 4800); assert(!x[2].mayTransmit(4800)); // Delayed grant.
    }
    {
        auto x = ready(); x[2].tick(3100, true); deliver(x, 3100);
        x[2].configure(2, 7, 43, {2,3}, 3150);
        assert(!x[2].mayTransmit(3151));
        x[2].tick(6200, true); assert(!x[2].mayTransmit(6200)); // Rekey required on topology change.
        x[2].tick(6201, false); x[2].tick(6202, true); deliver(x, 6202);
        assert(x[2].mayTransmit(6203));
    }
    {
        // Each member, including the coordinator, can hold the radio for an
        // hour without a duration cutoff. Contenders are denied throughout.
        for (Client holder = 1; holder <= 3; ++holder) {
            auto x = ready(); const Client contender = holder == 3 ? Client(1) : Client(holder + 1);
            x[holder].tick(3100, true); deliver(x, 3100);
            assert(x[holder].mayTransmit(3100));
            x[holder].permitTone = false;
            for (Time t = 3130; t <= 3603100; t += 30) {
                x[holder].tick(t, true); deliver(x, t);
                assert(x[holder].mayTransmit(t));
                assert(!x[holder].busyTone && !x[holder].permitTone);
                if ((t - 3100) % 30000 == 0) {
                    x[contender].tick(t, false); x[contender].busyTone = false;
                    x[contender].tick(t, true); deliver(x, t);
                    assert(!x[contender].mayTransmit(t) && x[contender].busyTone);
                    assert(x[holder].mayTransmit(t) && !x[holder].busyTone);
                    for (const auto& member : x)
                        if (member.first != contender) assert(!member.second.busyTone);
                    x[contender].busyTone = false;
                }
            }
            x[holder].tick(3603130, false); deliver(x, 3603130);
            x[contender].tick(3603500, false); x[contender].tick(3603530, true); deliver(x, 3603530);
            assert(!x[holder].mayTransmit(3603530) && x[contender].mayTransmit(3603530));
        }
    }
    // Fault-injection simulation: concurrent presses, lost/delayed/duplicated/reordered
    // messages and renewals. At most one cooperating client may transmit.
    struct Packet { Time at; Client from; Send send; };
    for (unsigned seed = 1; seed <= 100; ++seed) {
        std::mt19937 rng(seed); auto x = ready(); std::vector<Packet> packets;
        bool keys[4]{};
        for (Time t = 3100; t < 63100; t += 20) {
            for (Client i = 1; i <= 3; ++i) {
                if (rng() % 90 == 0) keys[i] = !keys[i];
                x[i].tick(t, keys[i]);
            }
            for (auto& p : x) {
                for (auto send : p.second.out) {
                    if (rng() % 12 == 0) continue;
                    Time delay = rng() % 450;
                    if (rng() % 30 == 0) delay += 2000;
                    packets.push_back({t + delay, p.first, send});
                    if (rng() % 20 == 0) packets.push_back({t + delay + 200, p.first, send});
                }
                p.second.out.clear();
            }
            std::shuffle(packets.begin(), packets.end(), rng);
            for (size_t i = 0; i < packets.size();) {
                if (packets[i].at <= t) {
                    auto p = packets[i]; x[p.send.target].receive(p.from, p.send.message, t);
                    packets.erase(packets.begin() + i);
                } else ++i;
            }
            int transmitters = 0;
            for (auto& p : x) transmitters += p.second.mayTransmit(t) ? 1 : 0;
            assert(transmitters <= 1);
        }
    }
    std::cout << "PASS: no cutoff in 3 one-hour transmissions, busy sound only on contender, no repeated alert on held denied key, release/rekey, parsing, contention, lease expiry, stale grants, authority, membership changes; 100 randomized network simulations.\n";
}
