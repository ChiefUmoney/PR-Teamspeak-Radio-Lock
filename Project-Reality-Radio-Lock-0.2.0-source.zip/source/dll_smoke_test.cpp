#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstring>
#include <iostream>
#include <thread>
#include "teamspeak/public_definitions.h"
#include "teamspeak/public_rare_definitions.h"
#include "ts3_functions.h"
#include "radio_core.h"
static std::atomic<bool> down{false}, protectedChannel{true}, deny{false}, deliverReplies{true};
static std::atomic<int> tones{0};
static std::atomic<int> busyTones{0}, permitTones{0};
static void (*incoming)(uint64,const char*,const char*,anyID,const char*,const char*);
static unsigned int listServers(uint64** result) { *result = static_cast<uint64*>(calloc(2,sizeof(uint64))); (*result)[0]=1; return 0; }
static unsigned int status(uint64,int* out) { *out = STATUS_CONNECTION_ESTABLISHED; return 0; }
static unsigned int self(uint64,anyID* out) { *out=2; return 0; }
static unsigned int channel(uint64,anyID,uint64* out) { *out=7; return 0; }
static unsigned int topic(uint64,uint64,size_t,char** out) { *out=_strdup(protectedChannel ? "Test [PR-RADIO]" : "Normal"); return 0; }
static unsigned int vad(uint64,const char*,char** out) { *out=_strdup("false"); return 0; }
static unsigned int variable(uint64,size_t flag,int* out) {
    *out = flag == CLIENT_INPUT_DEACTIVATED ? (down ? INPUT_ACTIVE : INPUT_DEACTIVATED) :
           flag == CLIENT_INPUT_HARDWARE ? 1 : 0;
    return 0;
}
static unsigned int members(uint64,uint64,anyID** out) {
    *out=static_cast<anyID*>(calloc(3,sizeof(anyID))); (*out)[0]=1; (*out)[1]=2; return 0;
}
static unsigned int clientInt(uint64,anyID,size_t,int* out) { *out=0; return 0; }
static unsigned int uid(uint64,anyID who,size_t,char** out) { *out=_strdup(who==1?"controller":"unit"); return 0; }
static unsigned int release(void* p) { free(p); return 0; }
static void print(uint64,const char*,PluginMessageTarget) {}
static unsigned int wave(uint64 server,const char* file) {
    assert(server==1 && file);
    const std::string p(file);
    if (p == "work/pr_radio_lock/busy.wav") ++busyTones;
    else if (p == "work/pr_radio_lock/permit.wav") ++permitTones;
    else assert(false);
    ++tones; return 0;
}
static void path(char* p,size_t size,const char*) { strcpy_s(p,size,"work/"); }
static void send(uint64 server,const char*,const char* text,int mode,const anyID* targets,const char*) {
    assert(mode == PluginCommandTarget_CLIENT && targets[0] == 1 && targets[1] == 0);
    radio::Message m; assert(radio::decode(text,m));
    if (m.kind != 'R' || !deliverReplies) return;
    m.kind = deny ? 'D' : 'G';
    auto reply=radio::encode(m);
    incoming(server,"pr_radio_lock",reply.c_str(),1,"Controller","controller");
}
static void wait(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
int main(int argc, char** argv) {
    auto dll = LoadLibraryA(argc>1 ? argv[1] : "work/pr_radio_lock.dll"); assert(dll);
    auto version=reinterpret_cast<int(*)()>(GetProcAddress(dll,"ts3plugin_apiVersion"));
    auto pluginVersion=reinterpret_cast<const char*(*)()>(GetProcAddress(dll,"ts3plugin_version"));
    auto init=reinterpret_cast<int(*)()>(GetProcAddress(dll,"ts3plugin_init"));
    auto shutdown=reinterpret_cast<void(*)()>(GetProcAddress(dll,"ts3plugin_shutdown"));
    auto pointers=reinterpret_cast<void(*)(TS3Functions)>(GetProcAddress(dll,"ts3plugin_setFunctionPointers"));
    auto registerId=reinterpret_cast<void(*)(const char*)>(GetProcAddress(dll,"ts3plugin_registerPluginID"));
    auto capture=reinterpret_cast<void(*)(uint64,short*,int,int,int*)>(GetProcAddress(dll,"ts3plugin_onEditCapturedVoiceDataEvent"));
    auto changed=reinterpret_cast<void(*)(uint64,uint64)>(GetProcAddress(dll,"ts3plugin_onUpdateChannelEvent"));
    incoming=reinterpret_cast<decltype(incoming)>(GetProcAddress(dll,"ts3plugin_onPluginCommandEvent"));
    assert(version && init && shutdown && pointers && registerId && capture && changed && incoming);
    assert(version()==26);
    assert(pluginVersion && !strcmp(pluginVersion(),"0.2.0"));
    TS3Functions api{};
    api.getServerConnectionHandlerList=listServers; api.getConnectionStatus=status;
    api.getClientID=self; api.getChannelOfClient=channel; api.getChannelVariableAsString=topic;
    api.getPreProcessorConfigValue=vad; api.getClientSelfVariableAsInt=variable;
    api.getChannelClientList=members; api.getClientVariableAsInt=clientInt;
    api.getClientVariableAsString=uid; api.freeMemory=release;
    api.printMessage=print; api.playWaveFile=wave; api.getPluginPath=path; api.sendPluginCommand=send;
    pointers(api); assert(init()==0); registerId("test-plugin-id");
    auto canSend=[&]() {
        short data[960]; for(auto& v:data) v=1000;
        int flags=2; capture(1,data,480,2,&flags);
        if (!(flags&2)) for(auto v:data) assert(v==0);
        return (flags&2)!=0;
    };
    assert(!canSend()); wait(3250); assert(!canSend());
    down=true; wait(180); assert(canSend()); // Real DLL parsed grant and opened capture.
    assert(permitTones==1 && busyTones==0);
    // Exercise the actual compiled DLL beyond the old 30-second boundary.
    for(int second=0;second<33;++second) { wait(1000); assert(canSend()); }
    assert(permitTones==1 && busyTones==0);
    down=false; wait(100); assert(!canSend());
    deny=true; down=true; wait(160); assert(!canSend());
    assert(busyTones==1 && permitTones==1);
    deny=false; wait(120); assert(!canSend()); // Must rekey after busy.
    assert(busyTones==1); // One local sound for this denied press.
    down=false; wait(100); down=true; wait(160); assert(canSend());
    deliverReplies=false; wait(1800); assert(!canSend()); // No controller heartbeat.
    down=false; protectedChannel=false; changed(1,7); wait(100); assert(canSend());
    protectedChannel=true; changed(1,7); assert(!canSend()); // No leakage on transition.
    wait(100); assert(!canSend());
    shutdown(); assert(FreeLibrary(dll));
    assert(tones>=3);
    std::cout << "PASS: Windows DLL v0.2.0, API 26, 33-second transmission stays open, local busy/permit sound paths, one alert per denied press, audio gate, busy latch, controller loss, ordinary channels, transitions, clean unload.\n";
}
